export class Cuisine{
  /* --------- Properties ---------  */
  id: number;
  cuisineName:string;
  productCount:number;
}
