//This model is for the Tags Bar at the top of the page
export class Tag{
  /* --------- Properties ---------  */
  id: number;
  tagName:string;
  productCount:number;
}
