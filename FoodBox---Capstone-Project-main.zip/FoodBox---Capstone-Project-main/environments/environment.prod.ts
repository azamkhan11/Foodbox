export const environment = {
  production: true,
  restUrl: 'https://someServer.com' //actual server on the internet; use HTTPS protocol
};
