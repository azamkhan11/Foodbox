import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //
  templateUrl: './app.component.html',
  styles: [
    ],
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  //This is root module that tells Angular how to assemble our application


}//end class
