package com.foodbox.restbackend.model;

public enum UserRole {
	ADMIN,
	CUSTOMER,
	GUEST
}
